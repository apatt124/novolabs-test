#Install Instructions For Alex's Code Test

1. Navigate to directory containing `package.json`
2. In terminal, run `npm install`
3. Once installation is complete, run `npm start` and navigate to [localhost:3000](http://localhost:3000)

**Libraries Used**
	*[React.js](https://reactjs.org/)
	*[create-react-app](https://github.com/facebook/create-react-app)
	*[react-table](https://github.com/react-tools/react-table)
